import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {requireAttended} from '../../../scripts/ui-test-policy.mjs';
export const state=JSON.parse(readFileSync('.scratch/find/48-attended-20261028/state.json','utf8'));
export const hostPid=Number(readFileSync('.scratch/find/48-attended-20261028/host-pid','utf8'));
export const env={...process.env,...state.environment};
export const pause=ms=>new Promise(r=>setTimeout(r,ms));
export const save=(name,value)=>writeFileSync(`${state.evidence}/${name}.json`,JSON.stringify(value,null,2)+'\n');
export const desktop=command=>JSON.parse(execFileSync('hyprctl',[command,'-j'],{env,encoding:'utf8'}));
export function attended(){requireAttended(command=>desktop(command));assert.equal(desktop('activewindow').pid,hostPid,'Focus the owned Find test instance on workspace 7');}
export async function connect(port){
 assert([9243,9244].includes(port));
 const proc=readFileSync(`/proc/${hostPid}/environ`,'utf8').split('\0');assert(proc.includes(`FREELENS_INTEGRATION_TESTING_DIR=${state.integration}`));assert(proc.includes(`HYPRLAND_INSTANCE_SIGNATURE=${state.environment.HYPRLAND_INSTANCE_SIGNATURE}`));
 const targets=await(await fetch(`http://127.0.0.1:${port}/json/list`,{signal:AbortSignal.timeout(4000)})).json();const target=targets.find(x=>port===9244||x.type==='page');assert(target);
 const ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true})});
 let next=0;const pending=new Map(),contexts=new Map(),events=[];
 ws.addEventListener('close',()=>{for(const p of pending.values())p.reject(Error('CDP closed'));pending.clear()});
 ws.addEventListener('message',({data})=>{const m=JSON.parse(data);if(m.method==='Network.responseReceived')events.push({url:m.params.response.url,status:m.params.response.status,requestId:m.params.requestId,timestamp:m.params.timestamp});if(m.method==='Runtime.executionContextCreated')contexts.set(m.params.context.id,m.params.context);if(m.method==='Runtime.executionContextDestroyed')contexts.delete(m.params.executionContextId);if(m.id){const p=pending.get(m.id);if(p){pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result)}}});
 const send=(method,params={})=>{if(method==='Page.bringToFront')attended();assert.equal(ws.readyState,WebSocket.OPEN);return new Promise((resolve,reject)=>{const id=++next;const timer=setTimeout(()=>{pending.delete(id);reject(Error(`CDP timeout: ${method}`))},12000);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params}))})};
 const read=async(expression,ctx)=>{const r=await send('Runtime.evaluate',{expression,contextId:ctx?.id,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value};
 await send('Runtime.enable');await pause(50);const root=()=>[...contexts.values()].find(c=>c.auxData?.isDefault&&/^https:\/\/renderer\./.test(c.origin));const cluster=()=>[...contexts.values()].find(c=>c.auxData?.isDefault&&/^https:\/\/[^.]+\.renderer\./.test(c.origin));
 const identity=await read('({pid:process.pid,integration:process.env.FREELENS_INTEGRATION_TESTING_DIR})',root());assert.equal(identity.integration,state.integration);if(port===9244)assert.equal(identity.pid,hostPid);
 return {send,read,contexts,events,root,cluster,close(){for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error('closed'))}pending.clear();ws.close()}};
}
