from pathlib import Path
import datetime,hashlib,json,os,shlex,subprocess,tempfile
root=Path.cwd(); scratch=root/'.scratch/find/48-attended-20261028'; evidence=root/'docs/verification/48/host/attended-hyprland-20261028'; evidence.mkdir(parents=True,exist_ok=True)
assert not (scratch/'state.json').exists(),'An attended test is already prepared; inspect its owner first'
rows=subprocess.check_output(['systemctl','--user','show-environment'],text=True).splitlines(); keys={'HYPRLAND_INSTANCE_SIGNATURE','WAYLAND_DISPLAY','XDG_RUNTIME_DIR','DISPLAY'}
env={**os.environ,**dict(r.split('=',1) for r in rows if r.partition('=')[0] in keys)}
info=json.loads(subprocess.check_output(['hyprctl','instances','-j'],env=env,text=True)); assert any(i['instance']==env['HYPRLAND_INSTANCE_SIGNATURE'] for i in info)
integration=Path(tempfile.mkdtemp(prefix='freelens-production-find-48-attended-')); profile=integration/'Freelens'; (profile/'kubeconfigs').mkdir(parents=True); (profile/'home/.freelens/extensions').mkdir(parents=True)
(profile/'lens-user-store.json').write_text(json.dumps({'preferences':{'syncKubeconfigEntries':[],'allowErrorReporting':False,'downloadKubectlBinaries':False}})); (profile/'package.json').write_text('{"name":"find-attended-profile","version":"0.0.0","private":true}')
with (profile/'kubeconfigs/fixture.yaml').open('w') as f: subprocess.run(['kubectl','--context','kind-freelens-json-logs-spike','config','view','--minify','--raw'],stdout=f,check=True)
(profile/'kubeconfigs/fixture.yaml').chmod(0o600)
ns='find-attended-48-'+str(os.getpid()); base=['kubectl','--context','kind-freelens-json-logs-spike']; subprocess.run(base+['create','-f','-'],input=json.dumps({'apiVersion':'v1','kind':'Namespace','metadata':{'name':ns,'labels':{'find-verification':'48','attended-find':'20261028'}}}),text=True,check=True)
uid=json.loads(subprocess.check_output(base+['get','ns',ns,'-o','json']))['metadata']['uid']
state={'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'integration':str(integration),'profile':str(profile),'namespace':ns,'namespaceUid':uid,'environment':{k:env[k] for k in keys if k in env},'evidence':str(evidence),'root':str(root),'pagePort':9243,'mainPort':9244,'tarballSha256':hashlib.sha256((root/'dist/freelens-readable-logs-0.1.34.tgz').read_bytes()).hexdigest()}
(scratch/'state.json').write_text(json.dumps(state,indent=2)+'\n')
lines=[json.dumps({'message':f'row {i}'+(' upstream' if i in (2,73,82,90) else ''),'index':i,'detail':'example source'},ensure_ascii=True) for i in range(120)]
script="cat <<'FIND_ATTENDED'\n"+'\n'.join(lines)+"\nFIND_ATTENDED\nsleep 86400"
pod={'apiVersion':'v1','kind':'Pod','metadata':{'name':'find-input','namespace':ns,'labels':{'find-verification':'48'}},'spec':{'containers':[{'name':'traces','image':'busybox:1.37.0@sha256:bdf57e528e45e4433820e045b29b4597825a1c9e38353532d90a01445013f82e','command':['sh','-c',script]}]}}
subprocess.run(base+['create','-f','-'],input=json.dumps(pod),text=True,check=True); subprocess.run(base+['-n',ns,'wait','pod/find-input','--for=condition=Ready','--timeout=60s'],check=True)
state['podUid']=json.loads(subprocess.check_output(base+['-n',ns,'get','pod/find-input','-o','json']))['metadata']['uid']; (scratch/'state.json').write_text(json.dumps(state,indent=2)+'\n')
command=shlex.join(['/usr/bin/python3',str(scratch/'launch.py')]); expr='hl.exec_cmd('+json.dumps(command)+', {workspace="7 silent", no_initial_focus=true})'
subprocess.run(['hyprctl','eval',expr],env=env,check=True); print(json.dumps({'prepared':True,'namespace':ns,'integration':str(integration),'tarballSha256':state['tarballSha256']}))
