from pathlib import Path
import json,os,subprocess
scratch=Path(__file__).resolve().parent; state=json.loads((scratch/'state.json').read_text()); env={**os.environ,**state['environment'],'FREELENS_INTEGRATION_TESTING_DIR':state['integration'],'CHOKIDAR_USEPOLLING':'1','CHOKIDAR_INTERVAL':'100','XDG_CONFIG_HOME':state['integration']+'/config','XDG_CACHE_HOME':state['integration']+'/cache'}
for k in ('ELECTRON_RUN_AS_NODE','FREELENS_UI_MODE'): env.pop(k,None)
cmd=['/usr/share/freelens/freelens','--ozone-platform=wayland','--remote-debugging-address=127.0.0.1','--remote-debugging-port=9243','--inspect=127.0.0.1:9244','--disable-renderer-backgrounding']
with (Path(state['evidence'])/'host.log').open('w') as f:
 p=subprocess.Popen(cmd,cwd='/home/max',env=env,stdout=f,stderr=subprocess.STDOUT); (scratch/'host-pid').write_text(str(p.pid)); code=p.wait(); (scratch/'host-exit').write_text(str(code))
