import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {state,hostPid,connect,pause,save,desktop} from './cdp.mjs';
const page=await connect(9243),main=await connect(9244);
try{
 await page.read(`global.LensExtensions.Renderer.Navigation.navigate('/extensions');true`,page.root());await pause(300);
 await page.read(`(()=>{const i=document.querySelector('input');Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(i,${JSON.stringify(state.root+'/dist/freelens-readable-logs-0.1.34.tgz')});i.dispatchEvent(new Event('input',{bubbles:true}));return true})()`,page.root());await pause(100);
 await page.read(`[...document.querySelectorAll('button')].find(b=>b.innerText==='Install').click();true`,page.root());
 let enabled=false;for(let n=0;n<300;n++){if(await page.read(`document.body.innerText.includes('Enabled')`,page.root())){enabled=true;break}await pause(100)}assert(enabled,'One fresh installation must become Enabled');
 const clusterId=await page.read(`(()=>{const R=global.LensExtensions.Renderer;const c=R.Catalog.getAllClusters()[0];if(!c)throw Error('Fixture cluster absent');R.Navigation.navigate('/cluster/'+c.id);return c.id})()`,page.root());
 for(let i=0;!page.cluster()&&i<200;i++)await pause(50);assert(page.cluster());await pause(1000);
 const entry=state.profile+'/node_modules/freelens-readable-logs/out/renderer-0.1.34.js';let bound=false;
 for(let i=0;i<200;i++){
  const proto=await page.send('Runtime.evaluate',{expression:`require(${JSON.stringify(entry)}).default.prototype`,contextId:page.cluster().id,objectGroup:'attended-bind'});
  if(proto.result.objectId){const objs=await page.send('Runtime.queryObjects',{prototypeObjectId:proto.result.objectId,objectGroup:'attended-bind'});const r=await page.send('Runtime.callFunctionOn',{objectId:objs.objects.objectId,functionDeclaration:'function(){global.__attendedFindRenderer=this.find(x=>x.isEnabled&&x.findRpc);return !!global.__attendedFindRenderer}',returnByValue:true});await page.send('Runtime.releaseObjectGroup',{objectGroup:'attended-bind'});if(r.result.value){bound=true;break}}await pause(50)
 }assert(bound);
 const params={namespace:state.namespace,pod:'find-input',podUid:state.podUid,clusterId};await page.read(`global.__attendedFindRenderer.navigate('readable-logs',${JSON.stringify(params)});true`,page.cluster());
 let count=0;for(let i=0;i<200;i++){count=await page.read(`document.querySelectorAll('.rl-record').length`,page.cluster());if(count===120)break;await pause(100)}assert.equal(count,120);
 const installed=state.profile+'/node_modules/freelens-readable-logs';const manifest=JSON.parse(readFileSync(installed+'/package.json'));
 const hash=p=>createHash('sha256').update(readFileSync(p)).digest('hex');const assets={};for(const a of [manifest.main,manifest.renderer,'out/find-worker-0.1.34.js']){assets[a]={installed:hash(installed+'/'+a),local:hash(state.root+'/'+a)};assert.equal(assets[a].installed,assets[a].local)}
 const clients=desktop('clients').filter(w=>w.pid===hostPid);assert.equal(clients.length,1);assert.equal(clients[0].workspace.id,7);
 const runtime=await main.read('({versions:process.versions,userData:process.mainModule.require("electron").app.getPath("userData"),cwd:process.cwd()})');
 save('prepared',{at:new Date().toISOString(),hostPid,package:manifest.name+'@'+manifest.version,tarballSha256:state.tarballSha256,assets,runtime,rows:count,window:clients[0],context:params});
 const screenshot=await page.send('Page.captureScreenshot',{format:'png'});const {writeFileSync}=await import('node:fs');writeFileSync(state.evidence+'/prepared.png',Buffer.from(screenshot.data,'base64'));
 console.log(JSON.stringify({ready:true,hostPid,workspace:7,rows:count,tarballSha256:state.tarballSha256}));
}finally{page.close();main.close()}
