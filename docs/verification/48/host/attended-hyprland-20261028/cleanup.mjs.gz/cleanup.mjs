// @ui-attended
import {execFileSync} from 'node:child_process';
import {readFileSync,existsSync,rmSync} from 'node:fs';
import assert from 'node:assert/strict';
import {connect,desktop,state,hostPid,save,env,pause,attended} from './cdp.mjs';
const before=desktop('activewindow'),ownsFocus=before.pid===hostPid;if(ownsFocus)attended();
const main=await connect(9244),result={hostPid,namespace:state.namespace,namespaceUid:state.namespaceUid,focusedTestBeforeCleanup:ownsFocus};
try{await main.read(`(()=>{setTimeout(()=>process.mainModule.require('electron').app.quit(),50);return true})()`)}finally{main.close()}
for(let i=0;i<100&&existsSync(`/proc/${hostPid}`);i++)await pause(50);assert(!existsSync(`/proc/${hostPid}`),'Owned host must exit before removing profile');
result.hostExit=readFileSync('.scratch/find/48-attended-20261028/host-exit','utf8');
const base=['--context','kind-freelens-json-logs-spike'];const ns=JSON.parse(execFileSync('kubectl',[...base,'get','ns',state.namespace,'-o','json'],{encoding:'utf8'}));assert.equal(ns.metadata.uid,state.namespaceUid);assert.equal(ns.metadata.labels['attended-find'],'20261028');
execFileSync('kubectl',[...base,'delete','ns',state.namespace,'--wait=true','--timeout=45s'],{encoding:'utf8',timeout:50000});result.namespaceDeleted=true;
assert(state.integration.startsWith('/tmp/freelens-production-find-48-attended-'));rmSync(state.integration,{recursive:true});result.profileRemoved=true;
// The test window took focus during this explicitly attended check. Restore the
// observed original terminal/workspace only while the session still owns focus.
if(ownsFocus&&process.env.FREELENS_UI_MODE==='attended'){
 const clients=desktop('clients');const original=clients.find(w=>w.address==='0x5637f33d1230'&&w.pid===3065834&&w.workspace.id===2);
 if(original){execFileSync('hyprctl',['eval','hl.dispatch(hl.dsp.focus({workspace=2}))'],{env,encoding:'utf8'});execFileSync('hyprctl',['eval',`hl.dispatch(hl.dsp.focus({window=${JSON.stringify('address:'+original.address)}}))`],{env,encoding:'utf8'});result.originalFocusRestored=true;}
}
const after=desktop('activewindow');result.after={workspace:desktop('activeworkspace').id,window:{address:after.address,class:after.class,pid:after.pid},pointer:desktop('cursorpos')};save('cleanup',result);console.log(JSON.stringify(result));
