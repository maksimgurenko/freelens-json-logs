"use strict";

// src/worker/find.ts
var import_node_worker_threads = require("node:worker_threads");

// src/core/find-protocol.ts
var FIND_QUERY_LIMIT = 16384;
var FIND_RANGE_LIMIT = 4096;
var FIND_SCOPE_LIMIT = FIND_RANGE_LIMIT;
var FIND_SOURCE_LIMIT = 5 * 1024 * 1024;
var keyFields = ["viewerEpoch", "targetEpoch", "instanceEpoch", "windowRevision", "messageRevision", "queryRevision"];
var object = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var integer = (value) => Number.isSafeInteger(value) && value >= 0;
function shape(value, required, optional = []) {
  return object(value) && required.every((key) => Object.hasOwn(value, key)) && Object.keys(value).every((key) => required.includes(key) || optional.includes(key));
}
function validKey(value) {
  return shape(value, keyFields) && keyFields.every((key) => integer(value[key]));
}
function sameRecordRef(a, b) {
  return a.context === b.context && a.occurrence === b.occurrence;
}
function validRef(value) {
  return shape(value, ["context", "occurrence"]) && typeof value.context === "string" && value.context.length > 0 && value.context.length <= 4096 && integer(value.occurrence);
}
function utf8Bytes(text) {
  let bytes = 0;
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i);
    if (code < 128) bytes++;
    else if (code < 2048) bytes += 2;
    else if (code >= 55296 && code <= 56319 && i + 1 < text.length && text.charCodeAt(i + 1) >= 56320 && text.charCodeAt(i + 1) <= 57343) {
      bytes += 4;
      i++;
    } else bytes += 3;
  }
  return bytes;
}
function sourceBoundary(text, offset) {
  return offset === 0 || offset === text.length || !(text.charCodeAt(offset - 1) >= 55296 && text.charCodeAt(offset - 1) <= 56319 && text.charCodeAt(offset) >= 56320 && text.charCodeAt(offset) <= 57343);
}
function validScope(value, records) {
  if (!shape(value, ["ref", "source", "start", "end"]) || !validRef(value.ref) || value.source !== "application" && value.source !== "message" || !integer(value.start) || !integer(value.end) || value.start >= value.end) return false;
  const record = records.find((record2) => sameRecordRef(record2.ref, value.ref));
  const source = record?.[value.source];
  return source !== void 0 && value.end <= source.length && sourceBoundary(source, value.start) && sourceBoundary(source, value.end);
}
function findRequestProblem(value) {
  if (!shape(value, ["requestId", "key", "query", "records", "work"], ["rangeInterest"]) || !integer(value.requestId) || value.requestId === 0 || !validKey(value.key) || !shape(value.query, ["text", "matchCase", "wholeWords"]) || typeof value.query.text !== "string" || typeof value.query.matchCase !== "boolean" || typeof value.query.wholeWords !== "boolean") return "invalid";
  if (value.query.text.length > FIND_QUERY_LIMIT) return "too-long";
  if (!Array.isArray(value.records) || value.records.length > 1e3) return "invalid";
  const seen = /* @__PURE__ */ new Set();
  let applicationUnits = 0, messageUnits = 0, context;
  for (const record of value.records) {
    if (!shape(record, ["ref", "application"], ["message"]) || !validRef(record.ref) || typeof record.application !== "string" || record.message !== void 0 && typeof record.message !== "string") return "invalid";
    context ??= record.ref.context;
    if (record.ref.context !== context || seen.has(record.ref.occurrence)) return "invalid";
    seen.add(record.ref.occurrence);
    applicationUnits += record.application.length;
    messageUnits += record.message?.length ?? 0;
    if (applicationUnits > FIND_SOURCE_LIMIT || messageUnits > FIND_SOURCE_LIMIT) return "invalid";
  }
  let bytes = 0;
  for (const record of value.records) {
    bytes += utf8Bytes(record.application);
    if (bytes > FIND_SOURCE_LIMIT) return "invalid";
  }
  if (value.work === "match") return value.rangeInterest === void 0 ? void 0 : "invalid";
  if (value.work !== "ranges" || !shape(value.rangeInterest, ["id", "scopes"]) || !integer(value.rangeInterest.id) || !Array.isArray(value.rangeInterest.scopes) || value.rangeInterest.scopes.length > FIND_SCOPE_LIMIT || !value.rangeInterest.scopes.every((scope) => validScope(scope, value.records))) return "invalid";
  return void 0;
}

// src/core/find-matcher.ts
function literalMatcher(query) {
  if (query.text.length > FIND_QUERY_LIMIT) throw new RangeError("Find query exceeds 16,384 UTF-16 units");
  let pattern = query.text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  if (!query.matchCase) pattern = `(?i:${pattern})`;
  if (query.wholeWords) pattern = `(?<![\\p{L}\\p{N}_])${pattern}(?![\\p{L}\\p{N}_])`;
  return new RegExp(pattern, "gu");
}
function sourceRanges(records, query, scopes) {
  const ranges = [];
  const coverage = scopes.map((scope) => ({ scope, complete: !query.text }));
  if (!query.text) return { ranges, coverage };
  const matcher2 = literalMatcher(query);
  const groups = /* @__PURE__ */ new Map();
  for (const entry of coverage) {
    const { ref, source } = entry.scope;
    const key = JSON.stringify([ref.context, ref.occurrence, source]);
    let group = groups.get(key);
    if (!group) {
      const record = records.find((record2) => record2.ref.context === ref.context && record2.ref.occurrence === ref.occurrence);
      const text = record?.[source];
      if (text === void 0) throw new RangeError("Range scope has no original source");
      group = { text, scopes: [] };
      groups.set(key, group);
    }
    group.scopes.push(entry);
  }
  let remainingGroups = groups.size;
  for (const group of groups.values()) {
    const limit = ranges.length + Math.ceil((FIND_RANGE_LIMIT - ranges.length) / remainingGroups--);
    matcher2.lastIndex = 0;
    const end = Math.max(...group.scopes.map((entry) => entry.scope.end));
    let overflow;
    for (let match; (match = matcher2.exec(group.text)) && match.index < end; ) {
      const start = match.index, finish = start + match[0].length;
      if (!group.scopes.some(({ scope }) => start < scope.end && finish > scope.start)) continue;
      if (ranges.length === limit) {
        overflow = start;
        break;
      }
      ranges.push({ ref: group.scopes[0].scope.ref, source: group.scopes[0].scope.source, start, end: finish });
    }
    for (const entry of group.scopes) entry.complete = overflow === void 0 || entry.scope.end <= overflow;
  }
  return { ranges, coverage };
}
var FindRecordMatcher = class {
  query;
  retained = /* @__PURE__ */ new Map();
  match(records, query) {
    if (this.query?.text !== query.text || this.query.matchCase !== query.matchCase || this.query.wholeWords !== query.wholeWords)
      this.retained.clear();
    this.query = { ...query };
    if (!query.text) {
      this.retained.clear();
      return [];
    }
    const matcher2 = literalMatcher(query);
    const hasMatch = (text) => {
      matcher2.lastIndex = 0;
      return matcher2.test(text);
    };
    const next = /* @__PURE__ */ new Map(), matches = [];
    for (const record of records) {
      const key = JSON.stringify(record.ref), previous = this.retained.get(key);
      const application = previous?.record.application === record.application ? previous.application : hasMatch(record.application);
      const message = record.message !== void 0 && (record.message === record.application ? application : previous?.record.message === record.message ? previous.message : hasMatch(record.message));
      next.set(key, { record, application, message });
      if (application || message) matches.push({ ref: record.ref, application, message });
    }
    this.retained = next;
    return matches;
  }
};

// src/worker/find.ts
if (!import_node_worker_threads.parentPort) throw new Error("Find must run in its owned worker");
var port = import_node_worker_threads.parentPort;
var matcher = new FindRecordMatcher();
port.on("message", (value) => {
  if (typeof value !== "object" || value === null || !("request" in value) || !("workerGeneration" in value) || !Number.isSafeInteger(value.workerGeneration) || value.workerGeneration <= 0 || findRequestProblem(value.request)) {
    throw new TypeError("Rejected invalid Find worker input");
  }
  const request = value.request;
  const identity = { requestId: request.requestId, key: request.key, workerGeneration: value.workerGeneration };
  let reply;
  try {
    reply = request.work === "match" ? { ...identity, kind: "matches", records: matcher.match(request.records, request.query) } : {
      ...identity,
      kind: "ranges",
      interestId: request.rangeInterest.id,
      ...sourceRanges(request.records, request.query, request.rangeInterest.scopes)
    };
  } catch {
    reply = { ...identity, kind: "failed", reason: "execution" };
  }
  port.postMessage(reply);
});
port.postMessage({ kind: "ready", version: "0.0.57" });
