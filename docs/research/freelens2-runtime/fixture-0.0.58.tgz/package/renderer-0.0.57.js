var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// host:react
var require_react = __commonJS({
  "host:react"(exports, module) {
    module.exports = globalThis.FreelensExtensionApi.React;
  }
});

// host:mobx
var require_mobx = __commonJS({
  "host:mobx"(exports, module) {
    module.exports = globalThis.FreelensExtensionApi.Mobx;
  }
});

// host:mobx-react
var require_mobx_react = __commonJS({
  "host:mobx-react"(exports, module) {
    module.exports = globalThis.FreelensExtensionApi.MobxReact;
  }
});

// host:@freelensapp/extensions
var require_extensions = __commonJS({
  "host:@freelensapp/extensions"(exports, module) {
    module.exports = globalThis.FreelensExtensionApi;
  }
});

// scripts/freelens2-runtime/renderer.js
var import_react = __toESM(require_react());
var Mobx2 = __toESM(require_mobx());
var import_mobx_react = __toESM(require_mobx_react());
var import_extensions2 = __toESM(require_extensions());

// scripts/freelens2-runtime/store.js
var import_extensions = __toESM(require_extensions());
var Mobx = __toESM(require_mobx());

// src/core/profiles.ts
var BUILTIN_PROFILE_ID = "default";
var LEVELS = ["TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL"];
function defaultMatching() {
  return { enabled: false, conditions: { labels: [] } };
}
function defaultFormatting() {
  return {
    messagePaths: ["/message", "/msg"],
    timestampPaths: ["/timestamp", "/time", "/@timestamp"],
    levelPaths: ["/level", "/severity", "/log.level", "/log/level"],
    inlinePaths: [],
    hiddenPaths: [],
    numericTimestamp: "unset",
    severityMappings: []
  };
}
function builtinProfile() {
  return { id: BUILTIN_PROFILE_ID, name: "Default", format: defaultFormatting(), matching: defaultMatching() };
}
function decodePath(path) {
  if (!path.startsWith("/") || /~(?![01])/u.test(path)) throw new Error(`Invalid field path ${JSON.stringify(path)}. Start with / and escape ~ as ~0 and / within a key as ~1.`);
  return path.slice(1).split("/").map((segment) => segment.replace(/~1/g, "/").replace(/~0/g, "~"));
}
function formattingProblems(value) {
  if (!value || typeof value !== "object") return ["Formatting rules must be an object."];
  const data = value;
  const errors = [];
  for (const [key, label] of [
    ["messagePaths", "Message"],
    ["timestampPaths", "Application timestamp"],
    ["levelPaths", "Level"],
    ["inlinePaths", "Inline fields"],
    ["hiddenPaths", "Hidden fields"]
  ]) {
    if (!Array.isArray(data[key])) {
      errors.push(`${label} paths must be a list.`);
      continue;
    }
    for (const path of data[key]) {
      if (typeof path !== "string") {
        errors.push(`${label} paths must be text.`);
        continue;
      }
      try {
        decodePath(path);
      } catch (error) {
        errors.push(`${label}: ${error.message}`);
      }
    }
  }
  if (!["unset", "seconds", "milliseconds"].includes(data.numericTimestamp)) errors.push("Choose unset, seconds or milliseconds for numeric timestamps.");
  if (!Array.isArray(data.severityMappings)) errors.push("Severity mappings must be a list.");
  else {
    const sources = /* @__PURE__ */ new Set();
    for (const mapping of data.severityMappings) {
      if (!mapping || typeof mapping.source !== "string" && typeof mapping.source !== "number" || (typeof mapping.source === "string" ? !mapping.source.trim() : !Number.isFinite(mapping.source))) {
        errors.push("Each severity mapping needs a nonempty text or finite numeric source.");
        continue;
      }
      const key = typeof mapping.source === "number" ? `number:${mapping.source}` : `text:${mapping.source.toLowerCase()}`;
      if (sources.has(key)) errors.push(`Duplicate severity source ${JSON.stringify(mapping.source)} (${typeof mapping.source}).`);
      sources.add(key);
      if (!LEVELS.includes(mapping.target)) errors.push("Severity targets must be TRACE, DEBUG, INFO, WARN, ERROR or FATAL.");
    }
  }
  return errors;
}
function profileProblems(profile, profiles) {
  const errors = [...formattingProblems(profile.format), ...matchingProblems(profile.matching)];
  if (typeof profile.id !== "string" || !profile.id || profile.id === BUILTIN_PROFILE_ID) errors.push("The built-in Default profile is read-only.");
  if (typeof profile.name !== "string" || !profile.name.trim()) errors.push("Enter a nonempty profile name.");
  else if (profile.name.trim().toLowerCase() === "default") errors.push("Default is reserved for the built-in profile.");
  else if (profiles.some((other) => other.id !== profile.id && other.name.trim().toLowerCase() === profile.name.trim().toLowerCase())) errors.push("Choose a unique profile name.");
  return errors;
}
function duplicateProfile(source, id, name) {
  return { id, name, format: structuredClone(source.format), matching: structuredClone(source.matching) };
}
function saveProfile(settings, draft) {
  const errors = profileProblems(draft, settings.profiles);
  if (errors.length) throw new Error(errors.join("\n"));
  const profile = structuredClone({ ...draft, name: draft.name.trim() });
  const exists = settings.profiles.some((value) => value.id === draft.id);
  return { ...settings, profiles: exists ? settings.profiles.map((value) => value.id === draft.id ? profile : value) : [...settings.profiles, profile] };
}
function matchingProblems(value) {
  if (!value || typeof value !== "object") return ["Profile matching settings must be an object."];
  const matching = value;
  if (typeof matching.enabled !== "boolean") return ["Choose whether this profile is enabled for matching."];
  if (!matching.conditions || typeof matching.conditions !== "object") return ["Match conditions must be an object."];
  const conditions = matching.conditions;
  if (Object.keys(matching).some((key) => !["enabled", "conditions"].includes(key)) || Object.keys(conditions).some((key) => !["namespace", "container", "labels"].includes(key))) return ["Only exact namespace, container name and Pod labels are supported for matching."];
  for (const key of ["namespace", "container"]) {
    if (conditions[key] !== void 0 && (typeof conditions[key] !== "string" || !conditions[key])) return [`Enter an exact ${key}, or omit its condition.`];
  }
  if (!Array.isArray(conditions.labels) || conditions.labels.some((label) => !label || typeof label.key !== "string" || !label.key || typeof label.value !== "string" || Object.keys(label).some((key) => !["key", "value"].includes(key)))) return ["Each Pod-label condition needs a nonempty key and an exact text value (which may be empty)."];
  if (new Set(conditions.labels.map((label) => label.key)).size !== conditions.labels.length) return ["Use each Pod-label key only once."];
  return [];
}
function settingsProblem(value) {
  if (!value || typeof value !== "object") return "Saved profile settings must be an object.";
  const settings = value;
  if (!Array.isArray(settings.profiles)) return "Saved profiles must be a list.";
  const ids = /* @__PURE__ */ new Set();
  for (const profile of settings.profiles) {
    if (!profile || typeof profile !== "object") return "A saved profile is invalid.";
    if (ids.has(profile.id)) return "Saved profile identities must be unique.";
    ids.add(profile.id);
    const problems = profileProblems(profile, settings.profiles.filter((other) => !!other && typeof other === "object" && typeof other.name === "string"));
    if (problems.length) return problems[0];
  }
  if (settings.globalDefault !== BUILTIN_PROFILE_ID && !ids.has(settings.globalDefault)) return "The global default refers to an unknown profile.";
}

// src/core/configuration.ts
var SCHEMA_VERSION = 3;
function defaultConfiguration() {
  return { schemaVersion: SCHEMA_VERSION, viewer: { inspection: "side" }, profiles: [], globalDefault: BUILTIN_PROFILE_ID };
}
function configurationData(stored) {
  const { __internal__: _hostMetadata, ...data } = stored;
  if (!Object.keys(data).length) return defaultConfiguration();
  if (data.schemaVersion === 1 && data.viewer && typeof data.viewer === "object" && isInspectionLayout(data.viewer.inspection)) {
    return { ...data, schemaVersion: SCHEMA_VERSION, profiles: [], globalDefault: BUILTIN_PROFILE_ID };
  }
  if (data.schemaVersion === 2 && Array.isArray(data.profiles)) {
    const migrated = {
      ...data,
      schemaVersion: SCHEMA_VERSION,
      profiles: data.profiles.map((profile) => profile && typeof profile === "object" ? { ...profile, matching: defaultMatching() } : profile)
    };
    if (!configurationProblem(migrated)) return migrated;
  }
  return data;
}
function isInspectionLayout(value) {
  return value === "inline" || value === "side" || value === "bottom";
}
function configurationProblem(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return "The saved configuration is not an object.";
  const data = value;
  if (data.schemaVersion !== SCHEMA_VERSION) return `Unsupported configuration schema ${String(data.schemaVersion)}. This version supports schema ${SCHEMA_VERSION}.`;
  if (!isInspectionLayout(data.viewer?.inspection)) return "The saved Inspection preference is invalid.";
  return settingsProblem(data);
}

// scripts/freelens2-runtime/store.js
var ProbeStore = class extends import_extensions.Common.Store.ExtensionStore {
  value = Mobx.observable.box(defaultConfiguration(), { deep: false });
  constructor() {
    super({
      configName: "readable-logs",
      clearInvalidConfig: false,
      syncOptions: { fireImmediately: false }
    });
  }
  fromStore(data) {
    const next = configurationData(data);
    const problem = configurationProblem(next);
    if (problem) throw Error(problem);
    Mobx.runInAction(() => this.value.set(next));
  }
  toJSON() {
    return this.value.get();
  }
  edit(layout, name) {
    const current = this.toJSON();
    const profile = duplicateProfile(builtinProfile(), "probe57", name);
    const next = { ...current, ...saveProfile(current, profile), viewer: { inspection: layout } };
    if (configurationProblem(next)) throw Error(configurationProblem(next));
    Mobx.runInAction(() => this.value.set(next));
  }
};
var store = new ProbeStore();

// scripts/freelens2-runtime/renderer.js
var Rpc = class extends import_extensions2.Renderer.Ipc {
};
var ProbeRenderer = class extends import_extensions2.Renderer.LensExtension {
  stops = [];
  pages = /* @__PURE__ */ new Set();
  reactions = [];
  clusterPages = [{
    id: "probe57",
    params: { namespace: "", pod: "", podUid: "", clusterId: "" },
    components: { Page: (0, import_mobx_react.observer)(({ params }) => {
      const [mounted] = import_react.default.useState(Date.now());
      const values = Object.fromEntries(Object.entries(params).map(([key, value]) => [key, value.get()]));
      import_react.default.useEffect(() => {
        const viewer = `page57-${mounted}`;
        const token = this.rpc.invoke("open", viewer);
        let closed = false;
        const close = async () => {
          if (closed) return;
          closed = true;
          await this.rpc.invoke("control", await token, "close");
        };
        this.pages.add(close);
        this.pageToken = token;
        return () => {
          this.pages.delete(close);
          void close().catch((error) => this.reactions.push({ closeError: String(error) }));
        };
      }, [mounted]);
      return import_react.default.createElement(
        "div",
        { id: "probe57-page", style: { background: "#000", color: "#fff", padding: 20 } },
        "Disposable v2 runtime contract fixture",
        import_react.default.createElement("pre", { id: "probe57-params" }, JSON.stringify(values)),
        import_react.default.createElement("pre", { id: "probe57-settings" }, JSON.stringify(store.toJSON()))
      );
    }) }
  }];
  kubeObjectMenuItems = [{ kind: "Pod", apiVersions: ["v1"], components: {
    MenuItem: ({ object, toolbar }) => import_react.default.createElement(
      import_extensions2.Renderer.Component.MenuItem,
      { onClick: () => {
        const cluster = import_extensions2.Renderer.Catalog.getActiveCluster();
        return this.navigate("probe57", { clusterId: cluster.id, namespace: object.getNs(), pod: object.getName(), podUid: object.metadata.uid });
      }, "data-probe57": toolbar ? "toolbar" : "menu" },
      import_react.default.createElement(import_extensions2.Renderer.Component.Icon, { material: "data_object", interactive: toolbar, tooltip: "Runtime probe 57" }),
      import_react.default.createElement("span", { className: "title" }, "Runtime probe 57")
    )
  } }];
  async onActivate() {
    globalThis.__probe57 = this;
    this.rpc = Rpc.createInstance(this);
    const state = await this.rpc.invoke("state");
    this.problem = state.problem;
    if (!state.problem) store.loadExtension(this);
    this.stops.push(Mobx2.reaction(() => store.value.get(), (value) => this.reactions.push({ layout: value.viewer.inspection })));
    this.stops.push(this.rpc.listen("probe57-echo", () => this.reactions.push({ echo: true })));
    this.ready = true;
  }
  async reset(confirmed) {
    const result = await this.rpc.invoke("reset", confirmed);
    if (!result.error) {
      this.problem = void 0;
      store.loadExtension(this);
    }
    return result;
  }
  get identity() {
    return {
      version: import_extensions2.Common.App.version,
      react: import_react.default.version,
      reactIdentity: import_react.default === globalThis.FreelensExtensionApi.React,
      mobxIdentity: Mobx2.reaction === globalThis.FreelensExtensionApi.Mobx.reaction,
      mobxObservable: globalThis.FreelensExtensionApi.Mobx.isObservable(store.value),
      href: location.href,
      visibility: document.visibilityState,
      focused: document.hasFocus()
    };
  }
  edit(layout, name) {
    store.edit(layout, name);
  }
  data() {
    return store.toJSON();
  }
  async onDeactivate() {
    await Promise.all([...this.pages].map((close) => close()));
    this.pages.clear();
    for (const stop of this.stops.splice(0)) stop();
    this.ready = false;
  }
};
export {
  ProbeRenderer as default
};
