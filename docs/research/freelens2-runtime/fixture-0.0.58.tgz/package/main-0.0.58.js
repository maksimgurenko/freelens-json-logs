var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// host:@freelensapp/extensions
var require_extensions = __commonJS({
  "host:@freelensapp/extensions"(exports, module) {
    module.exports = globalThis.FreelensExtensionApi;
  }
});

// host:mobx
var require_mobx = __commonJS({
  "host:mobx"(exports, module) {
    module.exports = globalThis.FreelensExtensionApi.Mobx;
  }
});

// scripts/freelens2-runtime/main.js
var import_extensions2 = __toESM(require_extensions());
var Mobx2 = __toESM(require_mobx());
import { app, BrowserWindow, ipcMain } from "electron";
import { Worker } from "node:worker_threads";
import { appendFileSync, readFileSync as readFileSync2 } from "node:fs";
import { dirname as dirname2, join as join2 } from "node:path";
import { fileURLToPath } from "node:url";

// src/main/find-service.ts
import { randomUUID } from "node:crypto";

// src/core/find-protocol.ts
var FIND_QUERY_LIMIT = 16384;
var FIND_RANGE_LIMIT = 4096;
var FIND_SCOPE_LIMIT = FIND_RANGE_LIMIT;
var FIND_SOURCE_LIMIT = 5 * 1024 * 1024;
var FIND_TIMEOUT_MS = 1e3;
var keyFields = ["viewerEpoch", "targetEpoch", "instanceEpoch", "windowRevision", "messageRevision", "queryRevision"];
var object = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var integer = (value) => Number.isSafeInteger(value) && value >= 0;
function shape(value, required, optional = []) {
  return object(value) && required.every((key) => Object.hasOwn(value, key)) && Object.keys(value).every((key) => required.includes(key) || optional.includes(key));
}
function validKey(value) {
  return shape(value, keyFields) && keyFields.every((key) => integer(value[key]));
}
function sameFindKey(a, b) {
  return keyFields.every((key) => a[key] === b[key]);
}
function sameRecordRef(a, b) {
  return a.context === b.context && a.occurrence === b.occurrence;
}
function validRef(value) {
  return shape(value, ["context", "occurrence"]) && typeof value.context === "string" && value.context.length > 0 && value.context.length <= 4096 && integer(value.occurrence);
}
function utf8Bytes(text) {
  let bytes = 0;
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i);
    if (code < 128) bytes++;
    else if (code < 2048) bytes += 2;
    else if (code >= 55296 && code <= 56319 && i + 1 < text.length && text.charCodeAt(i + 1) >= 56320 && text.charCodeAt(i + 1) <= 57343) {
      bytes += 4;
      i++;
    } else bytes += 3;
  }
  return bytes;
}
function sourceBoundary(text, offset) {
  return offset === 0 || offset === text.length || !(text.charCodeAt(offset - 1) >= 55296 && text.charCodeAt(offset - 1) <= 56319 && text.charCodeAt(offset) >= 56320 && text.charCodeAt(offset) <= 57343);
}
function validScope(value, records) {
  if (!shape(value, ["ref", "source", "start", "end"]) || !validRef(value.ref) || value.source !== "application" && value.source !== "message" || !integer(value.start) || !integer(value.end) || value.start >= value.end) return false;
  const record = records.find((record2) => sameRecordRef(record2.ref, value.ref));
  const source = record?.[value.source];
  return source !== void 0 && value.end <= source.length && sourceBoundary(source, value.start) && sourceBoundary(source, value.end);
}
function findRequestProblem(value) {
  if (!shape(value, ["requestId", "key", "query", "records", "work"], ["rangeInterest"]) || !integer(value.requestId) || value.requestId === 0 || !validKey(value.key) || !shape(value.query, ["text", "matchCase", "wholeWords"]) || typeof value.query.text !== "string" || typeof value.query.matchCase !== "boolean" || typeof value.query.wholeWords !== "boolean") return "invalid";
  if (value.query.text.length > FIND_QUERY_LIMIT) return "too-long";
  if (!Array.isArray(value.records) || value.records.length > 1e3) return "invalid";
  const seen = /* @__PURE__ */ new Set();
  let applicationUnits = 0, messageUnits = 0, context;
  for (const record of value.records) {
    if (!shape(record, ["ref", "application"], ["message"]) || !validRef(record.ref) || typeof record.application !== "string" || record.message !== void 0 && typeof record.message !== "string") return "invalid";
    context ??= record.ref.context;
    if (record.ref.context !== context || seen.has(record.ref.occurrence)) return "invalid";
    seen.add(record.ref.occurrence);
    applicationUnits += record.application.length;
    messageUnits += record.message?.length ?? 0;
    if (applicationUnits > FIND_SOURCE_LIMIT || messageUnits > FIND_SOURCE_LIMIT) return "invalid";
  }
  let bytes = 0;
  for (const record of value.records) {
    bytes += utf8Bytes(record.application);
    if (bytes > FIND_SOURCE_LIMIT) return "invalid";
  }
  if (value.work === "match") return value.rangeInterest === void 0 ? void 0 : "invalid";
  if (value.work !== "ranges" || !shape(value.rangeInterest, ["id", "scopes"]) || !integer(value.rangeInterest.id) || !Array.isArray(value.rangeInterest.scopes) || value.rangeInterest.scopes.length > FIND_SCOPE_LIMIT || !value.rangeInterest.scopes.every((scope) => validScope(scope, value.records))) return "invalid";
  return void 0;
}
function hasFindReplyIdentity(value, request, workerGeneration) {
  return object(value) && value.requestId === request.requestId && value.workerGeneration === workerGeneration && validKey(value.key) && sameFindKey(value.key, request.key);
}
function isFindReply(value, request, workerGeneration) {
  if (!hasFindReplyIdentity(value, request, workerGeneration)) return false;
  const base = ["requestId", "key", "workerGeneration", "kind"];
  if (value.kind === "failed") return shape(value, [...base, "reason"]) && ["too-long", "timeout", "execution"].includes(value.reason);
  if (value.kind === "matches") {
    if (request.work !== "match" || !shape(value, [...base, "records"]) || !Array.isArray(value.records) || value.records.length > request.records.length) return false;
    let previous = -1;
    for (const match of value.records) {
      if (!shape(match, ["ref", "application", "message"]) || !validRef(match.ref) || typeof match.application !== "boolean" || typeof match.message !== "boolean" || !match.application && !match.message) return false;
      const index = request.records.findIndex((record) => sameRecordRef(record.ref, match.ref));
      if (index <= previous || match.message && request.records[index].message === void 0) return false;
      previous = index;
    }
    return true;
  }
  const interest = request.rangeInterest;
  if (value.kind !== "ranges" || request.work !== "ranges" || !interest || value.interestId !== interest.id || !shape(value, [...base, "interestId", "ranges", "coverage"]) || !Array.isArray(value.ranges) || value.ranges.length > FIND_RANGE_LIMIT || !Array.isArray(value.coverage) || value.coverage.length !== interest.scopes.length) return false;
  const ends = /* @__PURE__ */ new Map();
  for (const range of value.ranges) {
    if (!validScope(range, request.records) || !interest.scopes.some((scope) => sameRecordRef(scope.ref, range.ref) && scope.source === range.source && scope.start < range.end && scope.end > range.start)) return false;
    const key = JSON.stringify([range.ref.context, range.ref.occurrence, range.source]);
    if (range.start < (ends.get(key) ?? 0)) return false;
    ends.set(key, range.end);
  }
  return value.coverage.every((entry, index) => {
    const scope = interest.scopes[index];
    return shape(entry, ["scope", "complete"]) && typeof entry.complete === "boolean" && validScope(entry.scope, request.records) && sameRecordRef(entry.scope.ref, scope.ref) && entry.scope.source === scope.source && entry.scope.start === scope.start && entry.scope.end === scope.end;
  });
}

// src/main/find-execution.ts
var FindExecution = class {
  slot;
  generation = 0;
  running;
  // One logical input descriptor, with exact matching ahead of its newest
  // decoration interest. Both operations share the same immutable source array.
  pending;
  closed = false;
  active = true;
  lastRequestId = 0;
  factory;
  version;
  clock;
  constructor(factory, version, clock = {
    now: () => performance.now(),
    delay: (ms, run) => {
      const timer = setTimeout(run, ms);
      return () => clearTimeout(timer);
    }
  }) {
    this.factory = factory;
    this.version = version;
    this.clock = clock;
  }
  submit(request) {
    const started = this.clock.now();
    if (this.closed || !this.active) return Promise.resolve(void 0);
    const problem = findRequestProblem(request);
    if (problem === "invalid") throw new TypeError("Rejected invalid Find input");
    if (request.requestId <= this.lastRequestId) return Promise.resolve(void 0);
    this.lastRequestId = request.requestId;
    if (problem === "too-long" || !request.query.text) {
      this.clearPending();
      if (this.running) {
        this.finish(this.running);
        void this.stop();
      }
      const identity = { requestId: request.requestId, key: request.key, workerGeneration: this.generation };
      return Promise.resolve(problem === "too-long" ? { ...identity, kind: "failed", reason: "too-long" } : request.work === "match" ? { ...identity, kind: "matches", records: [] } : {
        ...identity,
        kind: "ranges",
        interestId: request.rangeInterest.id,
        ranges: [],
        coverage: request.rangeInterest.scopes.map((scope) => ({ scope, complete: true }))
      });
    }
    const existing = this.pending?.match?.request ?? this.pending?.ranges?.request ?? this.running?.request;
    const sameInput = existing && sameFindKey(existing.key, request.key);
    if (sameInput) {
      if (existing.query.text !== request.query.text || existing.query.matchCase !== request.query.matchCase || existing.query.wholeWords !== request.query.wholeWords || existing.records.length !== request.records.length || !existing.records.every((record, index) => sameRecordRef(record.ref, request.records[index].ref) && record.application === request.records[index].application && record.message === request.records[index].message)) throw new TypeError("Find inputs changed without a new key");
      request = { ...request, query: existing.query, records: existing.records };
    } else this.clearPending();
    return new Promise((resolve) => {
      const older = this.pending?.[request.work];
      if (older) this.finish(older);
      const operation = { request, resolve, started, stopTimer: () => {
      } };
      this.pending ??= { key: request.key };
      this.pending[request.work] = operation;
      operation.stopTimer = this.clock.delay(Math.max(0, FIND_TIMEOUT_MS - (this.clock.now() - started)), () => this.timeout(operation));
      if (this.running && (!sameInput || request.work === "match" || this.running.request.work === "ranges")) {
        this.finish(this.running);
        void this.stop();
      }
      this.pump();
    });
  }
  pump() {
    if (this.closed || !this.active || this.running || this.slot?.stopping || !this.pending) return;
    this.running = this.pending.match ?? this.pending.ranges;
    if (!this.running) return;
    delete this.pending[this.running.request.work];
    if (!this.pending.match && !this.pending.ranges) this.pending = void 0;
    if (this.clock.now() - this.running.started >= FIND_TIMEOUT_MS) {
      this.timeout(this.running);
      return;
    }
    try {
      if (!this.slot) this.create();
    } catch {
      this.fail("execution");
      return;
    }
    if (this.slot?.ready) this.post();
  }
  create() {
    const worker = this.factory();
    let exited;
    const slot = {
      worker,
      generation: ++this.generation,
      ready: false,
      stopping: false,
      exit: new Promise((resolve) => {
        exited = resolve;
      })
    };
    this.slot = slot;
    worker.on("message", (value) => {
      if (this.slot !== slot || slot.stopping) return;
      if (!slot.ready) {
        if (typeof value === "object" && value !== null && "kind" in value && value.kind === "ready" && "version" in value && value.version === this.version) {
          slot.ready = true;
          this.post();
        } else this.fail("execution");
        return;
      }
      const operation = this.running;
      if (!operation || !hasFindReplyIdentity(value, operation.request, slot.generation)) return;
      if (this.clock.now() - operation.started >= FIND_TIMEOUT_MS) {
        this.timeout(operation);
        return;
      }
      if (isFindReply(value, operation.request, slot.generation)) {
        if (value.kind === "failed") {
          this.finishFailed(operation, value);
          void this.stop();
        } else {
          this.finish(operation, value);
          this.pump();
        }
      } else this.fail("execution");
    });
    worker.on("error", () => this.fail("execution"));
    worker.on("exit", () => {
      if (this.slot === slot) {
        this.slot = void 0;
        this.fail("execution");
      }
      worker.removeAllListeners();
      exited();
      this.pump();
    });
  }
  post() {
    if (!this.slot?.ready || this.slot.stopping || !this.running) return;
    if (this.clock.now() - this.running.started >= FIND_TIMEOUT_MS) {
      this.timeout(this.running);
      return;
    }
    try {
      this.slot.worker.postMessage({ request: this.running.request, workerGeneration: this.slot.generation });
    } catch {
      this.fail("execution");
    }
  }
  finish(operation, reply) {
    operation.stopTimer();
    if (this.running === operation) this.running = void 0;
    if (this.pending?.[operation.request.work] === operation) {
      delete this.pending[operation.request.work];
      if (!this.pending.match && !this.pending.ranges) this.pending = void 0;
    }
    operation.resolve(reply);
  }
  failure(operation, reason) {
    return { requestId: operation.request.requestId, key: operation.request.key, workerGeneration: this.generation, kind: "failed", reason };
  }
  finishFailed(operation, reply) {
    if (operation.request.work === "match" && this.pending?.ranges) this.finish(this.pending.ranges);
    this.finish(operation, reply);
  }
  timeout(operation) {
    const running = this.running === operation;
    if (!running && this.pending?.[operation.request.work] !== operation) return;
    this.finishFailed(operation, this.failure(operation, "timeout"));
    if (running) void this.stop();
  }
  fail(reason) {
    if (this.running) this.finishFailed(this.running, this.failure(this.running, reason));
    void this.stop();
  }
  clearPending() {
    if (this.pending?.match) this.finish(this.pending.match);
    if (this.pending?.ranges) this.finish(this.pending.ranges);
  }
  stop() {
    const slot = this.slot;
    if (!slot) return Promise.resolve();
    if (!slot.stopping) {
      slot.stopping = true;
      void slot.worker.terminate().catch(() => {
      });
    }
    return slot.exit;
  }
  async setActive(active) {
    if (this.closed) return;
    this.active = active;
    if (!active) await this.cancel();
  }
  async cancel() {
    this.clearPending();
    if (this.running) {
      this.finish(this.running);
      await this.stop();
    } else if (!this.active || this.closed || this.slot?.stopping) await this.stop();
  }
  async dispose() {
    this.closed = true;
    await this.cancel();
    await this.stop();
  }
};

// src/main/find-service.ts
var sameFrame = (a, b) => a.processId === b.processId && a.routingId === b.routingId;
var FindService = class {
  owners = /* @__PURE__ */ new Map();
  retiring = /* @__PURE__ */ new Map();
  senders = /* @__PURE__ */ new Map();
  stopWatch;
  closed = false;
  opening = /* @__PURE__ */ new Map();
  factory;
  version;
  watch;
  constructor(factory, version, watch = (sweep) => {
    const timer = setInterval(sweep, 1e3);
    timer.unref();
    return () => clearInterval(timer);
  }) {
    this.factory = factory;
    this.version = version;
    this.watch = watch;
  }
  present(sender, frame) {
    try {
      return !sender.isDestroyed() && sender.mainFrame.framesInSubtree.some((entry) => sameFrame(entry, frame));
    } catch {
      return false;
    }
  }
  async open(caller, viewer) {
    const receivedFrame = caller.senderFrame;
    const frame = receivedFrame && { processId: receivedFrame.processId, routingId: receivedFrame.routingId };
    if (this.closed || typeof viewer !== "string" || !viewer || viewer.length > 128 || !frame || !Number.isSafeInteger(frame.processId) || !Number.isSafeInteger(frame.routingId) || !this.present(caller.sender, frame)) throw new Error("Invalid Find viewer");
    const key = JSON.stringify([viewer, frame.processId, frame.routingId]);
    const previous = this.opening.get(key);
    let documentCurrent = true;
    const lost = () => {
      documentCurrent = false;
    };
    const navigated = (_event, _url, _status, _description, _main, processId, routingId) => {
      if (sameFrame(frame, { processId, routingId })) lost();
    };
    caller.sender.on("destroyed", lost);
    caller.sender.on("render-process-gone", lost);
    caller.sender.on("did-frame-navigate", navigated);
    const opening = (async () => {
      if (previous) await previous.catch(() => {
      });
      const old = [...this.owners.values(), ...this.retiring.keys()].filter((owner) => owner.sender === caller.sender && owner.viewer === viewer && sameFrame(owner, frame));
      await Promise.all(old.map((owner) => this.retire(owner)));
      if (this.closed || !documentCurrent || !this.present(caller.sender, frame)) throw new Error("Disposed Find viewer");
      const token = randomUUID();
      this.owners.set(token, {
        token,
        viewer,
        sender: caller.sender,
        processId: frame.processId,
        routingId: frame.routingId,
        execution: new FindExecution(this.factory, this.version)
      });
      this.observe(caller.sender);
      this.stopWatch ??= this.watch(() => this.sweep());
      return token;
    })();
    this.opening.set(key, opening);
    try {
      return await opening;
    } finally {
      caller.sender.removeListener("destroyed", lost);
      caller.sender.removeListener("render-process-gone", lost);
      caller.sender.removeListener("did-frame-navigate", navigated);
      if (this.opening.get(key) === opening) this.opening.delete(key);
    }
  }
  owned(caller, token) {
    const owner = this.owners.get(token);
    if (this.closed || !owner || caller.sender !== owner.sender || !caller.senderFrame || !sameFrame(owner, caller.senderFrame)) throw new Error("Foreign or disposed Find viewer");
    if (!this.present(owner.sender, owner)) {
      void this.retire(owner);
      throw new Error("Foreign or disposed Find viewer");
    }
    return owner;
  }
  submit(caller, token, request) {
    return this.owned(caller, token).execution.submit(request);
  }
  cancel(caller, token) {
    return this.owned(caller, token).execution.cancel();
  }
  setActive(caller, token, active) {
    if (typeof active !== "boolean") throw new TypeError("Invalid Find activity");
    return this.owned(caller, token).execution.setActive(active);
  }
  close(caller, token) {
    return this.retire(this.owned(caller, token));
  }
  observe(sender) {
    if (this.senders.has(sender)) return;
    const lost = () => {
      for (const owner of this.owners.values()) if (owner.sender === sender) void this.retire(owner);
    };
    const navigated = (_event, _url, _status, _description, _main, processId, routingId) => {
      for (const owner of this.owners.values()) if (owner.sender === sender && sameFrame(owner, { processId, routingId })) void this.retire(owner);
      this.sweep();
    };
    sender.on("destroyed", lost);
    sender.on("render-process-gone", lost);
    sender.on("did-frame-navigate", navigated);
    this.senders.set(sender, () => {
      sender.removeListener("destroyed", lost);
      sender.removeListener("render-process-gone", lost);
      sender.removeListener("did-frame-navigate", navigated);
    });
  }
  sweep() {
    for (const owner of this.owners.values()) if (!this.present(owner.sender, owner)) void this.retire(owner);
  }
  retire(owner) {
    if (!this.owners.delete(owner.token)) return this.retiring.get(owner) ?? Promise.resolve();
    if (![...this.owners.values()].some((other) => other.sender === owner.sender)) {
      this.senders.get(owner.sender)?.();
      this.senders.delete(owner.sender);
    }
    if (!this.owners.size) {
      this.stopWatch?.();
      this.stopWatch = void 0;
    }
    const closing = owner.execution.dispose();
    this.retiring.set(owner, closing);
    void closing.finally(() => this.retiring.delete(owner));
    return closing;
  }
  async dispose() {
    this.closed = true;
    for (const owner of this.owners.values()) void this.retire(owner);
    await Promise.allSettled([...this.opening.values(), ...this.retiring.values()]);
  }
};

// src/adapter/window-visibility.ts
function watchWindowVisibility(window, clusterId, received) {
  const contents = window.webContents;
  const emit = () => {
    let selected = null;
    if (!window.isDestroyed() && window.isVisible() && !window.isMinimized()) {
      try {
        const path = new URL(contents.getURL()).pathname;
        if (path === `/cluster/${encodeURIComponent(clusterId)}`) selected = clusterId;
      } catch {
      }
    }
    received(selected);
  };
  const events = ["show", "hide", "minimize", "restore", "closed"];
  const navigation = ["did-navigate", "did-navigate-in-page"];
  for (const event of events) window.on(event, emit);
  for (const event of navigation) contents.on(event, emit);
  emit();
  return () => {
    for (const event of events) window.removeListener(event, emit);
    for (const event of navigation) contents.removeListener(event, emit);
  };
}

// src/adapter/configuration-file.ts
import { constants, copyFileSync, lstatSync, mkdirSync, readFileSync, renameSync, unlinkSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { randomUUID as randomUUID2 } from "node:crypto";

// src/core/profiles.ts
var BUILTIN_PROFILE_ID = "default";
var LEVELS = ["TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL"];
function defaultMatching() {
  return { enabled: false, conditions: { labels: [] } };
}
function defaultFormatting() {
  return {
    messagePaths: ["/message", "/msg"],
    timestampPaths: ["/timestamp", "/time", "/@timestamp"],
    levelPaths: ["/level", "/severity", "/log.level", "/log/level"],
    inlinePaths: [],
    hiddenPaths: [],
    numericTimestamp: "unset",
    severityMappings: []
  };
}
function builtinProfile() {
  return { id: BUILTIN_PROFILE_ID, name: "Default", format: defaultFormatting(), matching: defaultMatching() };
}
function decodePath(path) {
  if (!path.startsWith("/") || /~(?![01])/u.test(path)) throw new Error(`Invalid field path ${JSON.stringify(path)}. Start with / and escape ~ as ~0 and / within a key as ~1.`);
  return path.slice(1).split("/").map((segment) => segment.replace(/~1/g, "/").replace(/~0/g, "~"));
}
function formattingProblems(value) {
  if (!value || typeof value !== "object") return ["Formatting rules must be an object."];
  const data = value;
  const errors = [];
  for (const [key, label] of [
    ["messagePaths", "Message"],
    ["timestampPaths", "Application timestamp"],
    ["levelPaths", "Level"],
    ["inlinePaths", "Inline fields"],
    ["hiddenPaths", "Hidden fields"]
  ]) {
    if (!Array.isArray(data[key])) {
      errors.push(`${label} paths must be a list.`);
      continue;
    }
    for (const path of data[key]) {
      if (typeof path !== "string") {
        errors.push(`${label} paths must be text.`);
        continue;
      }
      try {
        decodePath(path);
      } catch (error) {
        errors.push(`${label}: ${error.message}`);
      }
    }
  }
  if (!["unset", "seconds", "milliseconds"].includes(data.numericTimestamp)) errors.push("Choose unset, seconds or milliseconds for numeric timestamps.");
  if (!Array.isArray(data.severityMappings)) errors.push("Severity mappings must be a list.");
  else {
    const sources = /* @__PURE__ */ new Set();
    for (const mapping of data.severityMappings) {
      if (!mapping || typeof mapping.source !== "string" && typeof mapping.source !== "number" || (typeof mapping.source === "string" ? !mapping.source.trim() : !Number.isFinite(mapping.source))) {
        errors.push("Each severity mapping needs a nonempty text or finite numeric source.");
        continue;
      }
      const key = typeof mapping.source === "number" ? `number:${mapping.source}` : `text:${mapping.source.toLowerCase()}`;
      if (sources.has(key)) errors.push(`Duplicate severity source ${JSON.stringify(mapping.source)} (${typeof mapping.source}).`);
      sources.add(key);
      if (!LEVELS.includes(mapping.target)) errors.push("Severity targets must be TRACE, DEBUG, INFO, WARN, ERROR or FATAL.");
    }
  }
  return errors;
}
function profileProblems(profile, profiles) {
  const errors = [...formattingProblems(profile.format), ...matchingProblems(profile.matching)];
  if (typeof profile.id !== "string" || !profile.id || profile.id === BUILTIN_PROFILE_ID) errors.push("The built-in Default profile is read-only.");
  if (typeof profile.name !== "string" || !profile.name.trim()) errors.push("Enter a nonempty profile name.");
  else if (profile.name.trim().toLowerCase() === "default") errors.push("Default is reserved for the built-in profile.");
  else if (profiles.some((other) => other.id !== profile.id && other.name.trim().toLowerCase() === profile.name.trim().toLowerCase())) errors.push("Choose a unique profile name.");
  return errors;
}
function duplicateProfile(source, id, name) {
  return { id, name, format: structuredClone(source.format), matching: structuredClone(source.matching) };
}
function saveProfile(settings, draft) {
  const errors = profileProblems(draft, settings.profiles);
  if (errors.length) throw new Error(errors.join("\n"));
  const profile = structuredClone({ ...draft, name: draft.name.trim() });
  const exists = settings.profiles.some((value) => value.id === draft.id);
  return { ...settings, profiles: exists ? settings.profiles.map((value) => value.id === draft.id ? profile : value) : [...settings.profiles, profile] };
}
function matchingProblems(value) {
  if (!value || typeof value !== "object") return ["Profile matching settings must be an object."];
  const matching = value;
  if (typeof matching.enabled !== "boolean") return ["Choose whether this profile is enabled for matching."];
  if (!matching.conditions || typeof matching.conditions !== "object") return ["Match conditions must be an object."];
  const conditions = matching.conditions;
  if (Object.keys(matching).some((key) => !["enabled", "conditions"].includes(key)) || Object.keys(conditions).some((key) => !["namespace", "container", "labels"].includes(key))) return ["Only exact namespace, container name and Pod labels are supported for matching."];
  for (const key of ["namespace", "container"]) {
    if (conditions[key] !== void 0 && (typeof conditions[key] !== "string" || !conditions[key])) return [`Enter an exact ${key}, or omit its condition.`];
  }
  if (!Array.isArray(conditions.labels) || conditions.labels.some((label) => !label || typeof label.key !== "string" || !label.key || typeof label.value !== "string" || Object.keys(label).some((key) => !["key", "value"].includes(key)))) return ["Each Pod-label condition needs a nonempty key and an exact text value (which may be empty)."];
  if (new Set(conditions.labels.map((label) => label.key)).size !== conditions.labels.length) return ["Use each Pod-label key only once."];
  return [];
}
function settingsProblem(value) {
  if (!value || typeof value !== "object") return "Saved profile settings must be an object.";
  const settings = value;
  if (!Array.isArray(settings.profiles)) return "Saved profiles must be a list.";
  const ids = /* @__PURE__ */ new Set();
  for (const profile of settings.profiles) {
    if (!profile || typeof profile !== "object") return "A saved profile is invalid.";
    if (ids.has(profile.id)) return "Saved profile identities must be unique.";
    ids.add(profile.id);
    const problems = profileProblems(profile, settings.profiles.filter((other) => !!other && typeof other === "object" && typeof other.name === "string"));
    if (problems.length) return problems[0];
  }
  if (settings.globalDefault !== BUILTIN_PROFILE_ID && !ids.has(settings.globalDefault)) return "The global default refers to an unknown profile.";
}

// src/core/configuration.ts
var SCHEMA_VERSION = 3;
function defaultConfiguration() {
  return { schemaVersion: SCHEMA_VERSION, viewer: { inspection: "side" }, profiles: [], globalDefault: BUILTIN_PROFILE_ID };
}
function configurationData(stored) {
  const { __internal__: _hostMetadata, ...data } = stored;
  if (!Object.keys(data).length) return defaultConfiguration();
  if (data.schemaVersion === 1 && data.viewer && typeof data.viewer === "object" && isInspectionLayout(data.viewer.inspection)) {
    return { ...data, schemaVersion: SCHEMA_VERSION, profiles: [], globalDefault: BUILTIN_PROFILE_ID };
  }
  if (data.schemaVersion === 2 && Array.isArray(data.profiles)) {
    const migrated = {
      ...data,
      schemaVersion: SCHEMA_VERSION,
      profiles: data.profiles.map((profile) => profile && typeof profile === "object" ? { ...profile, matching: defaultMatching() } : profile)
    };
    if (!configurationProblem(migrated)) return migrated;
  }
  return data;
}
function isInspectionLayout(value) {
  return value === "inline" || value === "side" || value === "bottom";
}
function configurationProblem(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return "The saved configuration is not an object.";
  const data = value;
  if (data.schemaVersion !== SCHEMA_VERSION) return `Unsupported configuration schema ${String(data.schemaVersion)}. This version supports schema ${SCHEMA_VERSION}.`;
  if (!isInspectionLayout(data.viewer?.inspection)) return "The saved Inspection preference is invalid.";
  return settingsProblem(data);
}

// src/adapter/configuration-file.ts
function inspectConfiguration(path) {
  let text;
  try {
    text = readFileSync(path, "utf8");
  } catch (error) {
    if (error.code === "ENOENT") return { data: defaultConfiguration() };
    return { problem: `Unable to read Readable logs settings: ${String(error)}` };
  }
  try {
    const parsed = JSON.parse(text);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return { problem: "The saved configuration is not an object." };
    const data = configurationData(parsed);
    return { data, problem: configurationProblem(data) };
  } catch (error) {
    return { problem: `Readable logs settings contain invalid JSON: ${String(error)}` };
  }
}
function resetConfiguration(path, confirmed) {
  if (confirmed !== true) return { error: "Reset canceled. Saved settings were not changed." };
  let backup, temporary;
  try {
    if (!lstatSync(path).isFile()) throw new Error("Settings must be a regular file to preserve a backup.");
    const original = readFileSync(path);
    const directory = join(dirname(path), "backups");
    mkdirSync(directory, { recursive: true, mode: 448 });
    backup = join(directory, `readable-logs-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}-${randomUUID2()}.json`);
    copyFileSync(path, backup, constants.COPYFILE_EXCL);
    if (!readFileSync(backup).equals(original)) throw new Error("Backup verification failed.");
    if (!readFileSync(path).equals(original)) throw new Error("Settings changed during backup; reset stopped.");
    temporary = join(dirname(path), `.readable-logs-reset-${randomUUID2()}.tmp`);
    writeFileSync(temporary, JSON.stringify(defaultConfiguration(), null, 2) + "\n", { flag: "wx", mode: 384 });
    renameSync(temporary, path);
    return { backup };
  } catch (error) {
    return { backup, error: `Unable to back up and reset Readable logs settings. Saved settings were not replaced. ${String(error)}` };
  } finally {
    if (temporary) {
      try {
        unlinkSync(temporary);
      } catch {
      }
    }
  }
}

// scripts/freelens2-runtime/store.js
var import_extensions = __toESM(require_extensions());
var Mobx = __toESM(require_mobx());
var ProbeStore = class extends import_extensions.Common.Store.ExtensionStore {
  value = Mobx.observable.box(defaultConfiguration(), { deep: false });
  constructor() {
    super({
      configName: "readable-logs",
      clearInvalidConfig: false,
      syncOptions: { fireImmediately: false }
    });
  }
  fromStore(data) {
    const next = configurationData(data);
    const problem = configurationProblem(next);
    if (problem) throw Error(problem);
    Mobx.runInAction(() => this.value.set(next));
  }
  toJSON() {
    return this.value.get();
  }
  edit(layout, name) {
    const current = this.toJSON();
    const profile = duplicateProfile(builtinProfile(), "probe57", name);
    const next = { ...current, ...saveProfile(current, profile), viewer: { inspection: layout } };
    if (configurationProblem(next)) throw Error(configurationProblem(next));
    Mobx.runInAction(() => this.value.set(next));
  }
};
var store = new ProbeStore();

// scripts/freelens2-runtime/main.js
var Rpc = class extends import_extensions2.Main.Ipc {
};
var telemetry = globalThis.__probe57Telemetry ??= { starts: 0, exits: 0, live: /* @__PURE__ */ new Set(), events: [] };
function log(event, detail = {}) {
  const value = { at: Date.now(), event, ...detail };
  telemetry.events.push(value);
  appendFileSync(join2(process.env.FREELENS_INTEGRATION_TESTING_DIR, "probe57-events.jsonl"), JSON.stringify(value) + "\n");
}
process.once("exit", () => log("process-exit", { live: telemetry.live.size, starts: telemetry.starts, exits: telemetry.exits }));
var ProbeMain = class extends import_extensions2.Main.LensExtension {
  quit() {
    app.quit();
  }
  stops = [];
  problem = void 0;
  settingsPath = "";
  find = void 0;
  closing = void 0;
  onActivate() {
    globalThis.__probe57 = this;
    this.closing = void 0;
    this.settingsPath = join2(app.getPath("userData"), "extension-store", this.storeName, "readable-logs.json");
    this.problem = inspectConfiguration(this.settingsPath).problem;
    if (!this.problem) store.loadExtension(this);
    const source = readFileSync2(join2(dirname2(fileURLToPath(import.meta.url)), "worker-0.0.58.cjs"), "utf8");
    this.find = new FindService(() => {
      const worker = new Worker(source, { eval: true });
      telemetry.starts++;
      telemetry.live.add(worker);
      log("worker-start", { threadId: worker.threadId });
      worker.once("exit", (code) => {
        telemetry.live.delete(worker);
        telemetry.exits++;
        log("worker-exit", { code, live: telemetry.live.size });
      });
      return worker;
    }, "0.0.58");
    const rpc = Rpc.createInstance(this);
    this.rpc = rpc;
    const identity = (event) => ({
      senderId: event.sender.id,
      senderPid: event.sender.getOSProcessId(),
      frame: event.senderFrame && { processId: event.senderFrame.processId, routingId: event.senderFrame.routingId, url: event.senderFrame.url },
      windowId: BrowserWindow.fromWebContents(event.sender)?.id
    });
    rpc.handle("identity", (event) => identity(event));
    rpc.handle("state", () => this.state());
    rpc.handle("open", (event, viewer) => this.find.open(event, viewer));
    rpc.handle("submit", (event, token, request) => this.find.submit(event, token, request));
    rpc.handle("control", (event, token, action, active) => {
      if (action === "close") return this.find.close(event, token);
      if (action === "cancel") return this.find.cancel(event, token);
      if (action === "active") return this.find.setActive(event, token, active);
      throw Error("Invalid control");
    });
    rpc.handle("reset", (_event, confirmed) => {
      if (!this.problem) throw Error("No recovery needed");
      const result = resetConfiguration(this.settingsPath, confirmed);
      if (!result.error) {
        this.problem = void 0;
        store.loadExtension(this);
      }
      return result;
    });
    rpc.handle("visibility", (event, clusterId) => {
      const owner = BrowserWindow.fromWebContents(event.sender);
      let result;
      const stop = watchWindowVisibility(owner, clusterId, (selected) => {
        result = selected;
      });
      stop();
      return { identity: identity(event), selected: result, focused: owner.isFocused(), visible: owner.isVisible() };
    });
    this.stops.push(rpc.listen("ping", () => log("ping")));
    this.stops.push(Mobx2.reaction(() => store.value.get(), () => log("main-reaction", { layout: store.toJSON().viewer.inspection })));
    let quitting = false;
    const beforeQuit = (event) => {
      if (quitting) return;
      event.preventDefault();
      quitting = true;
      void this.onDeactivate().then(() => {
        log("quit-after-cleanup", this.state());
        app.quit();
      });
    };
    app.on("before-quit", beforeQuit);
    this.stops.push(() => app.removeListener("before-quit", beforeQuit));
    log("activate", {
      version: import_extensions2.Common.App.version,
      versions: process.versions,
      settingsProblem: this.problem,
      mobxIdentity: Mobx2.reaction === globalThis.FreelensExtensionApi.Mobx.reaction
    });
  }
  state() {
    const f = this.find;
    return {
      problem: this.problem,
      settingsPath: this.settingsPath,
      configuration: store.toJSON(),
      workers: { starts: telemetry.starts, exits: telemetry.exits, live: telemetry.live.size },
      service: f && { owners: f.owners.size, retiring: f.retiring.size, senders: f.senders.size, opening: f.opening.size, watch: !!f.stopWatch },
      handlers: [...ipcMain._invokeHandlers.keys()].filter((key) => key.startsWith("extensions@")),
      extensionListeners: ipcMain.eventNames().filter((key) => typeof key === "string" && key.startsWith("extensions@")).map((key) => [key, ipcMain.listenerCount(key)]),
      stops: this.stops.length
    };
  }
  async onDeactivate() {
    if (this.closing) return this.closing;
    this.closing = (async () => {
      log("deactivate-start", this.state());
      await this.find?.dispose();
      for (const stop of this.stops.splice(0)) stop();
      log("deactivate-end", this.state());
    })();
    return this.closing;
  }
};
export {
  ProbeMain as default
};
